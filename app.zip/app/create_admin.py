import asyncio
from sqlalchemy import select
from app.db.session import AsyncSessionLocal
from app.models.models import User, UserRole
from app.core.security import get_password_hash


async def create_initial_admin():
    """Create initial system administrator account"""
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(User).where(User.username == "admin")
        )
        existing_admin = result.scalar_one_or_none()

        if existing_admin:
            print("Admin user already exists!")
            return

        # Create admin user
        admin_user = User(
            username="admin",
            email="hemanthk.b@proton.me",
            hashed_password=get_password_hash("Likitha@123"),
            role=UserRole.SYSTEM_ADMINISTRATOR,
            is_active=True
        )

        db.add(admin_user)
        await db.commit()
        await db.refresh(admin_user)

        print("=" * 50)
        print("Initial admin user created successfully!")
        print(f"Username: {admin_user.username}")
        print(f"Email: {admin_user.email}")
        print(f"Role: {admin_user.role.value}")
        print("Password: Admin@123")
        print("=" * 50)
        print("⚠️  IMPORTANT: Change this password after first login!")


if __name__ == "__main__":
    # Import models to register them
    from app.models import models

    asyncio.run(create_initial_admin())