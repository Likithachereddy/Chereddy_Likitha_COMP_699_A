from pydantic import BaseModel, EmailStr, Field, ConfigDict
from typing import Optional, List, Dict, Any
from datetime import date, datetime
from enum import Enum


# Enums
class UserRole(str, Enum):
    RESEARCH_COORDINATOR = "Research Coordinator"
    TRIAL_ADMINISTRATOR = "Trial Administrator"
    SYSTEM_ADMINISTRATOR = "System Administrator"


class TrialStatus(str, Enum):
    PLANNING = "Planning"
    ACTIVE_ENROLLING = "Active-Enrolling"
    ACTIVE_NOT_ENROLLING = "Active-Not Enrolling"
    SUSPENDED = "Suspended"
    COMPLETED = "Completed"
    TERMINATED = "Terminated"


class MatchCategory(str, Enum):
    STRONG_MATCH = "Strong Match"
    POTENTIAL_MATCH = "Potential Match"
    WEAK_MATCH = "Weak Match"
    DISQUALIFIED = "Disqualified"


# User Schemas
class UserBase(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    role: UserRole


class UserCreate(UserBase):
    pass


class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    role: Optional[UserRole] = None
    is_active: Optional[bool] = None


class UserResponse(UserBase):
    id: int
    is_active: bool
    created_at: datetime
    profile_photo_url: Optional[str] = None
    force_password_change: bool


    model_config = ConfigDict(from_attributes=True)


class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: Optional[str] = None


# Patient Schemas
class PatientBase(BaseModel):
    patient_id: int
    first_name: str
    last_name: str
    date_of_birth: date
    gender: Optional[str] = None
    ethnicity: Optional[str] = None


class PatientCreate(PatientBase):
    pass


class PatientUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    gender: Optional[str] = None
    ethnicity: Optional[str] = None
    is_active: Optional[bool] = None


class PatientResponse(BaseModel):
    id: int
    patient_id: int
    first_name: str
    last_name: str
    date_of_birth: date
    gender: Optional[str] = None
    profile_photo_url: Optional[str] = None
    ethnicity: Optional[str] = None
    is_active: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Diagnosis Schemas
class DiagnosisBase(BaseModel):
    icd10_code: str = Field(..., max_length=10)
    description: str = Field(..., max_length=500)
    diagnosis_date: date


class DiagnosisCreate(DiagnosisBase):
    patient_id: int


class DiagnosisUpdate(BaseModel):
    icd10_code: Optional[str] = None
    description: Optional[str] = None
    diagnosis_date: Optional[date] = None


class DiagnosisResponse(DiagnosisBase):
    id: int
    patient_id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Medication Schemas
class MedicationBase(BaseModel):
    drug_name: str = Field(..., max_length=200)
    dosage: str = Field(..., max_length=100)
    frequency: str = Field(..., max_length=100)
    route: str = Field(..., max_length=50)
    start_date: date
    end_date: Optional[date] = None


class MedicationCreate(MedicationBase):
    patient_id: int


class MedicationUpdate(BaseModel):
    drug_name: Optional[str] = None
    dosage: Optional[str] = None
    frequency: Optional[str] = None
    route: Optional[str] = None
    end_date: Optional[date] = None


class MedicationResponse(MedicationBase):
    id: int
    patient_id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Lab Result Schemas
class LabResultBase(BaseModel):
    test_name: str = Field(..., max_length=200)
    result_value: float
    unit: str = Field(..., max_length=50)
    reference_range: Optional[str] = Field(None, max_length=100)
    test_date: date


class LabResultCreate(LabResultBase):
    patient_id: int


class LabResultUpdate(BaseModel):
    test_name: Optional[str] = None
    result_value: Optional[float] = None
    unit: Optional[str] = None
    reference_range: Optional[str] = None
    test_date: Optional[date] = None


class LabResultResponse(LabResultBase):
    id: int
    patient_id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Treatment History Schemas
class TreatmentHistoryBase(BaseModel):
    treatment_type: str = Field(..., max_length=100)
    description: str
    treatment_date: date
    outcome: Optional[str] = None


class TreatmentHistoryCreate(TreatmentHistoryBase):
    patient_id: int


class TreatmentHistoryUpdate(BaseModel):
    treatment_type: Optional[str] = None
    description: Optional[str] = None
    treatment_date: Optional[date] = None
    outcome: Optional[str] = None


class TreatmentHistoryResponse(TreatmentHistoryBase):
    id: int
    patient_id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Biomarker Schemas
class BiomarkerBase(BaseModel):
    marker_name: str = Field(..., max_length=200)
    result: str = Field(..., max_length=100)
    test_date: date


class BiomarkerCreate(BiomarkerBase):
    patient_id: int


class BiomarkerUpdate(BaseModel):
    marker_name: Optional[str] = None
    result: Optional[str] = None
    test_date: Optional[date] = None


class BiomarkerResponse(BiomarkerBase):
    id: int
    patient_id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Performance Status Schemas
class PerformanceStatusBase(BaseModel):
    ecog_score: Optional[int] = Field(None, ge=0, le=5)
    karnofsky_score: Optional[int] = Field(None, ge=0, le=100)
    assessment_date: date


class PerformanceStatusCreate(PerformanceStatusBase):
    patient_id: int


class PerformanceStatusUpdate(BaseModel):
    ecog_score: Optional[int] = Field(None, ge=0, le=5)
    karnofsky_score: Optional[int] = Field(None, ge=0, le=100)
    assessment_date: Optional[date] = None


class PerformanceStatusResponse(PerformanceStatusBase):
    id: int
    patient_id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Clinical Trial Schemas
class TrialDiseaseFocusBase(BaseModel):
    icd10_code: str = Field(..., max_length=10)
    description: Optional[str] = None


class TrialDiseaseFocusCreate(TrialDiseaseFocusBase):
    pass


class ClinicalTrialBase(BaseModel):
    protocol_number: str = Field(..., max_length=50)
    nct_number: Optional[str] = Field(None, max_length=50)
    title: str = Field(..., max_length=500)
    sponsor_name: str = Field(..., max_length=200)
    principal_investigator: str = Field(..., max_length=200)
    phase: Optional[str] = Field(None, max_length=20)
    status: TrialStatus = TrialStatus.PLANNING
    target_enrollment: Optional[int] = None
    estimated_duration: Optional[str] = None
    study_sites: Optional[List[Dict[str, Any]]] = None
    contact_info: Optional[Dict[str, Any]] = None


class ClinicalTrialCreate(ClinicalTrialBase):
    disease_focus: List[TrialDiseaseFocusCreate]


class ClinicalTrialUpdate(BaseModel):
    nct_number: Optional[str] = None
    title: Optional[str] = None
    sponsor_name: Optional[str] = None
    principal_investigator: Optional[str] = None
    phase: Optional[str] = None
    status: Optional[TrialStatus] = None
    target_enrollment: Optional[int] = None
    estimated_duration: Optional[str] = None
    study_sites: Optional[List[Dict[str, Any]]] = None
    contact_info: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None


class ClinicalTrialResponse(ClinicalTrialBase):
    id: int
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


# Eligibility Criteria Schemas
class InclusionCriterionBase(BaseModel):
    criterion_type: str = Field(..., max_length=50)
    criterion_data: Dict[str, Any]
    importance_weight: int = Field(..., ge=1, le=5)
    logical_operator: str = Field(default="AND", max_length=10)


class InclusionCriterionCreate(InclusionCriterionBase):
    trial_id: int


class ExclusionCriterionBase(BaseModel):
    criterion_type: str = Field(..., max_length=50)
    criterion_data: Dict[str, Any]


class ExclusionCriterionCreate(ExclusionCriterionBase):
    trial_id: int


# Match Schemas
class MatchResultDetail(BaseModel):
    trial_id: int
    protocol_number: str
    trial_title: str
    match_score: float
    match_category: MatchCategory
    confidence_score: float
    criteria_met: List[Dict[str, Any]]
    criteria_not_met: List[Dict[str, Any]]
    criteria_missing_data: List[Dict[str, Any]]
    exclusion_criteria_met: List[Dict[str, Any]]
    recommendations: List[str]
    contact_info: Optional[Dict[str, Any]] = None


class MatchSessionResponse(BaseModel):
    session_id: int
    patient_id: int
    patient_name: str
    session_date: datetime
    trials_evaluated: int
    match_results: List[MatchResultDetail]

    model_config = ConfigDict(from_attributes=True)


# Report Schema
class MatchReportRequest(BaseModel):
    session_id: int