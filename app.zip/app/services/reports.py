from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image, KeepTogether
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.pdfgen import canvas
from datetime import datetime
from typing import List, Dict, Any
import io


class MediConnectReportTemplate:
    """Custom page template for MediConnect reports"""

    def __init__(self, title):
        self.title = title

    def header_footer(self, canvas, doc):
        """Add header and footer to each page"""
        canvas.saveState()

        # Header
        # Company name and logo area
        canvas.setFont('Helvetica-Bold', 16)
        canvas.setFillColor(colors.HexColor('#0d47a1'))
        canvas.drawString(72, letter[1] - 50, "MediConnect")

        # Tagline
        canvas.setFont('Helvetica', 8)
        canvas.setFillColor(colors.HexColor('#666666'))
        canvas.drawString(72, letter[1] - 64, "Clinical Trial Patient Matching Solutions")

        # Header line
        canvas.setStrokeColor(colors.HexColor('#0d47a1'))
        canvas.setLineWidth(2)
        canvas.line(72, letter[1] - 72, letter[0] - 72, letter[1] - 72)

        # Footer
        canvas.setFont('Helvetica', 8)
        canvas.setFillColor(colors.HexColor('#666666'))

        # Footer line
        canvas.setStrokeColor(colors.HexColor('#e0e0e0'))
        canvas.setLineWidth(1)
        canvas.line(72, 50, letter[0] - 72, 50)

        # Footer text
        footer_text = f"MediConnect Clinical Trial Matching Report | Generated {datetime.now().strftime('%B %d, %Y')}"
        canvas.drawString(72, 35, footer_text)

        # Page number
        page_num = canvas.getPageNumber()
        canvas.drawRightString(letter[0] - 72, 35, f"Page {page_num}")

        # Confidentiality notice
        canvas.setFont('Helvetica-Bold', 7)
        canvas.setFillColor(colors.HexColor('#d32f2f'))
        canvas.drawCentredString(letter[0] / 2, 20, "CONFIDENTIAL - FOR MEDICAL USE ONLY")

        canvas.restoreState()


class ReportGenerator:
    """Generate professional PDF match reports with MediConnect branding"""

    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()

    def _setup_custom_styles(self):
        """Setup custom paragraph styles for professional medical reports"""

        # Main Title
        self.styles.add(ParagraphStyle(
            name='MediConnectTitle',
            parent=self.styles['Heading1'],
            fontSize=22,
            textColor=colors.HexColor('#0d47a1'),
            spaceAfter=6,
            spaceBefore=12,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        ))

        # Subtitle
        self.styles.add(ParagraphStyle(
            name='Subtitle',
            parent=self.styles['Normal'],
            fontSize=11,
            textColor=colors.HexColor('#666666'),
            spaceAfter=20,
            alignment=TA_CENTER,
            fontName='Helvetica'
        ))

        # Section Header
        self.styles.add(ParagraphStyle(
            name='SectionHeader',
            parent=self.styles['Heading2'],
            fontSize=14,
            textColor=colors.HexColor('#0d47a1'),
            spaceAfter=10,
            spaceBefore=16,
            fontName='Helvetica-Bold',
            borderWidth=0,
            borderColor=colors.HexColor('#0d47a1'),
            borderPadding=5,
            backColor=colors.HexColor('#e3f2fd')
        ))

        # Subsection Header
        self.styles.add(ParagraphStyle(
            name='SubsectionHeader',
            parent=self.styles['Heading3'],
            fontSize=12,
            textColor=colors.HexColor('#1565c0'),
            spaceAfter=8,
            spaceBefore=10,
            fontName='Helvetica-Bold'
        ))

        # Trial Title
        self.styles.add(ParagraphStyle(
            name='TrialTitle',
            parent=self.styles['Heading3'],
            fontSize=11,
            textColor=colors.HexColor('#0d47a1'),
            spaceAfter=6,
            spaceBefore=12,
            fontName='Helvetica-Bold',
            leftIndent=0
        ))

        # Body Text
        self.styles.add(ParagraphStyle(
            name='MediConnectBody',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#333333'),
            alignment=TA_JUSTIFY,
            spaceAfter=6,
            leading=14
        ))

        # Small Text
        self.styles.add(ParagraphStyle(
            name='SmallText',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#666666'),
            spaceAfter=4,
            leading=12
        ))

        # Match Categories
        self.styles.add(ParagraphStyle(
            name='StrongMatch',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#2e7d32'),
            fontName='Helvetica-Bold',
            spaceAfter=4
        ))

        self.styles.add(ParagraphStyle(
            name='PotentialMatch',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#f57c00'),
            fontName='Helvetica-Bold',
            spaceAfter=4
        ))

        self.styles.add(ParagraphStyle(
            name='WeakMatch',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#c62828'),
            fontName='Helvetica-Bold',
            spaceAfter=4
        ))

        self.styles.add(ParagraphStyle(
            name='Disqualified',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#757575'),
            fontName='Helvetica-Bold',
            spaceAfter=4
        ))

        # Bullet list
        self.styles.add(ParagraphStyle(
            name='BulletList',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#333333'),
            leftIndent=20,
            spaceAfter=3,
            bulletIndent=10
        ))

    def generate_match_report(
            self,
            patient_data: Dict[str, Any],
            match_results: List[Dict[str, Any]],
            session_date: datetime
    ) -> bytes:
        """Generate comprehensive match report as PDF bytes"""

        buffer = io.BytesIO()

        # Create document with custom template
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=72,
            leftMargin=72,
            topMargin=90,
            bottomMargin=60
        )

        # Create template for headers/footers
        template = MediConnectReportTemplate("Clinical Trial Matching Report")

        story = []

        # ===== COVER PAGE =====
        story.append(Spacer(1, 0.5 * inch))

        # Main Title
        story.append(Paragraph(
            "Clinical Trial Patient Matching Report",
            self.styles['MediConnectTitle']
        ))

        # Subtitle
        story.append(Paragraph(
            "Comprehensive Analysis and Recommendations",
            self.styles['Subtitle']
        ))

        story.append(Spacer(1, 0.3 * inch))

        # Report metadata box
        metadata_data = [
            ['Report Generated:', datetime.now().strftime('%B %d, %Y at %I:%M %p')],
            ['Matching Session:', session_date.strftime('%B %d, %Y at %I:%M %p')],
            ['Report ID:', f"MC-{datetime.now().strftime('%Y%m%d%H%M%S')}"],
            ['Status:', 'CONFIDENTIAL']
        ]

        metadata_table = Table(metadata_data, colWidths=[2.2 * inch, 3.8 * inch])
        metadata_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f5f5f5')),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#0d47a1')),
            ('TEXTCOLOR', (1, 0), (1, -1), colors.HexColor('#333333')),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e0e0e0')),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ]))

        story.append(metadata_table)
        story.append(Spacer(1, 0.5 * inch))

        # ===== PATIENT INFORMATION =====
        story.append(Paragraph("Patient Information", self.styles['SectionHeader']))
        story.append(Spacer(1, 0.1 * inch))

        patient_table_data = [
            ['Patient ID:', patient_data.get('patient_id', 'N/A')],
            ['Name:', f"{patient_data.get('first_name', '')} {patient_data.get('last_name', '')}"],
            ['Date of Birth:', patient_data.get('date_of_birth', 'N/A')],
            ['Age:', self._calculate_age(patient_data.get('date_of_birth', ''))],
            ['Gender:', patient_data.get('gender', 'N/A')],
            ['Ethnicity:', patient_data.get('ethnicity', 'N/A')]
        ]

        patient_table = Table(patient_table_data, colWidths=[2 * inch, 4 * inch])
        patient_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.white),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#0d47a1')),
            ('TEXTCOLOR', (1, 0), (1, -1), colors.HexColor('#333333')),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('LINEBELOW', (0, 0), (-1, -2), 0.5, colors.HexColor('#e0e0e0')),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))

        story.append(patient_table)
        story.append(Spacer(1, 0.3 * inch))

        # ===== EXECUTIVE SUMMARY =====
        story.append(Paragraph("Executive Summary", self.styles['SectionHeader']))
        story.append(Spacer(1, 0.1 * inch))

        # Count by category
        strong_matches = sum(1 for r in match_results if r['match_category'] == 'Strong Match')
        potential_matches = sum(1 for r in match_results if r['match_category'] == 'Potential Match')
        weak_matches = sum(1 for r in match_results if r['match_category'] == 'Weak Match')
        disqualified = sum(1 for r in match_results if r['match_category'] == 'Disqualified')

        summary_data = [
            ['Category', 'Count', 'Percentage', 'Match Score Range'],
            ['Strong Matches', str(strong_matches), f"{strong_matches / len(match_results) * 100:.1f}%", '80-100%'],
            ['Potential Matches', str(potential_matches), f"{potential_matches / len(match_results) * 100:.1f}%",
             '60-79%'],
            ['Weak Matches', str(weak_matches), f"{weak_matches / len(match_results) * 100:.1f}%", '40-59%'],
            ['Disqualified', str(disqualified), f"{disqualified / len(match_results) * 100:.1f}%", '<40%'],
            ['Total Trials Evaluated', str(len(match_results)), '100%', '-']
        ]

        summary_table = Table(summary_data, colWidths=[2.2 * inch, 0.8 * inch, 1.2 * inch, 1.8 * inch])
        summary_table.setStyle(TableStyle([
            # Header row
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0d47a1')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),

            # Data rows
            ('BACKGROUND', (0, 1), (-1, 1), colors.HexColor('#e8f5e9')),  # Strong
            ('BACKGROUND', (0, 2), (-1, 2), colors.HexColor('#fff3e0')),  # Potential
            ('BACKGROUND', (0, 3), (-1, 3), colors.HexColor('#ffebee')),  # Weak
            ('BACKGROUND', (0, 4), (-1, 4), colors.HexColor('#f5f5f5')),  # Disqualified
            ('BACKGROUND', (0, 5), (-1, 5), colors.HexColor('#e3f2fd')),  # Total

            ('FONTNAME', (0, 1), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('ALIGN', (1, 1), (-1, -1), 'CENTER'),
            ('ALIGN', (0, 1), (0, -1), 'LEFT'),

            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#bdbdbd')),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))

        story.append(summary_table)
        story.append(Spacer(1, 0.3 * inch))

        # Recommendation summary
        if strong_matches > 0:
            story.append(Paragraph(
                f"<b>Clinical Recommendation:</b> {strong_matches} trial(s) identified as strong match(es). "
                f"Immediate clinical review recommended for enrollment consideration.",
                self.styles['MediConnectBody']
            ))
        elif potential_matches > 0:
            story.append(Paragraph(
                f"<b>Clinical Recommendation:</b> {potential_matches} trial(s) identified as potential match(es). "
                f"Further evaluation recommended to determine eligibility.",
                self.styles['MediConnectBody']
            ))
        else:
            story.append(Paragraph(
                "<b>Clinical Recommendation:</b> No strong or potential matches identified at this time. "
                "Consider expanding search criteria or monitoring for new trial opportunities.",
                self.styles['MediConnectBody']
            ))

        story.append(PageBreak())

        # ===== DETAILED MATCH RESULTS =====
        story.append(Paragraph("Detailed Match Results", self.styles['SectionHeader']))
        story.append(Spacer(1, 0.15 * inch))

        # Sort match results by score (highest first)
        sorted_results = sorted(match_results, key=lambda x: x['match_score'], reverse=True)

        for idx, result in enumerate(sorted_results, 1):
            # Create trial section with KeepTogether to avoid page breaks in middle of trial
            trial_elements = []

            # Trial number and title
            trial_elements.append(Paragraph(
                f"Trial #{idx}: {result['protocol_number']}",
                self.styles['TrialTitle']
            ))

            trial_elements.append(Paragraph(
                result['trial_title'],
                self.styles['MediConnectBody']
            ))

            trial_elements.append(Spacer(1, 0.1 * inch))

            # Match information box
            category = result['match_category']
            match_info_data = [
                ['Match Category:', category],
                ['Match Score:', f"{result['match_score']:.1f}%"],
                ['Confidence:', f"{result['confidence_score']:.1f}%"],
                ['Phase:', result.get('phase', 'N/A')],
                ['Status:', result.get('status', 'N/A')]
            ]

            match_info_table = Table(match_info_data, colWidths=[1.5 * inch, 4.5 * inch])

            # Color coding based on category
            if category == 'Strong Match':
                bg_color = colors.HexColor('#e8f5e9')
                text_color = colors.HexColor('#2e7d32')
            elif category == 'Potential Match':
                bg_color = colors.HexColor('#fff3e0')
                text_color = colors.HexColor('#f57c00')
            elif category == 'Weak Match':
                bg_color = colors.HexColor('#ffebee')
                text_color = colors.HexColor('#c62828')
            else:
                bg_color = colors.HexColor('#f5f5f5')
                text_color = colors.HexColor('#757575')

            match_info_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, -1), bg_color),
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#0d47a1')),
                ('TEXTCOLOR', (1, 0), (1, 0), text_color),  # Category in color
                ('TEXTCOLOR', (1, 1), (1, -1), colors.HexColor('#333333')),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#bdbdbd')),
                ('TOPPADDING', (0, 0), (-1, -1), 5),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
                ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ]))

            trial_elements.append(match_info_table)
            trial_elements.append(Spacer(1, 0.1 * inch))

            # Criteria Analysis
            if result['criteria_met']:
                trial_elements.append(Paragraph(
                    "✓ <b>Inclusion Criteria Met:</b>",
                    self.styles['SubsectionHeader']
                ))

                for criterion in result['criteria_met'][:5]:
                    trial_elements.append(Paragraph(
                        f"• {criterion.get('type', 'N/A')}: {self._format_criterion_data(criterion)}",
                        self.styles['SmallText']
                    ))

                if len(result['criteria_met']) > 5:
                    trial_elements.append(Paragraph(
                        f"<i>...and {len(result['criteria_met']) - 5} more criteria</i>",
                        self.styles['SmallText']
                    ))

            if result['criteria_not_met']:
                trial_elements.append(Spacer(1, 0.05 * inch))
                trial_elements.append(Paragraph(
                    "✗ <b>Criteria Not Met:</b>",
                    self.styles['SubsectionHeader']
                ))

                for criterion in result['criteria_not_met'][:3]:
                    trial_elements.append(Paragraph(
                        f"• {criterion.get('reason', 'N/A')}",
                        self.styles['SmallText']
                    ))

                if len(result['criteria_not_met']) > 3:
                    trial_elements.append(Paragraph(
                        f"<i>...and {len(result['criteria_not_met']) - 3} more criteria</i>",
                        self.styles['SmallText']
                    ))

            if result['exclusion_criteria_met']:
                trial_elements.append(Spacer(1, 0.05 * inch))
                trial_elements.append(Paragraph(
                    "⊗ <b>Exclusion Criteria Met (Disqualifying):</b>",
                    self.styles['SubsectionHeader']
                ))

                for criterion in result['exclusion_criteria_met']:
                    trial_elements.append(Paragraph(
                        f"• {criterion.get('reason', 'N/A')}",
                        self.styles['SmallText']
                    ))

            # Recommendations
            if result['recommendations']:
                trial_elements.append(Spacer(1, 0.05 * inch))
                trial_elements.append(Paragraph(
                    "<b>Clinical Recommendations:</b>",
                    self.styles['SubsectionHeader']
                ))

                for rec in result['recommendations'][:3]:
                    trial_elements.append(Paragraph(
                        f"• {rec}",
                        self.styles['SmallText']
                    ))

            # Contact information for strong/potential matches
            if category in ['Strong Match', 'Potential Match'] and result.get('contact_info'):
                trial_elements.append(Spacer(1, 0.05 * inch))
                contact = result['contact_info']

                contact_data = [
                    ['Principal Investigator:', contact.get('pi_name', 'N/A')],
                    ['Email:', contact.get('email', 'N/A')],
                    ['Phone:', contact.get('phone', 'N/A')],
                    ['Institution:', contact.get('institution', 'N/A')]
                ]

                contact_table = Table(contact_data, colWidths=[1.5 * inch, 4.5 * inch])
                contact_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f0f4ff')),
                    ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                    ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 0), (-1, -1), 8),
                    ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#333333')),
                    ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#bdbdbd')),
                    ('TOPPADDING', (0, 0), (-1, -1), 4),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
                    ('LEFTPADDING', (0, 0), (-1, -1), 8),
                ]))

                trial_elements.append(Paragraph("<b>Contact Information:</b>", self.styles['SubsectionHeader']))
                trial_elements.append(contact_table)

            # Add all trial elements with KeepTogether
            story.append(KeepTogether(trial_elements))
            story.append(Spacer(1, 0.2 * inch))

            # Add separator line between trials
            if idx < len(sorted_results):
                separator_data = [['']]
                separator_table = Table(separator_data, colWidths=[6 * inch])
                separator_table.setStyle(TableStyle([
                    ('LINEABOVE', (0, 0), (-1, 0), 1, colors.HexColor('#e0e0e0')),
                ]))
                story.append(separator_table)
                story.append(Spacer(1, 0.15 * inch))

            # Page break every 3 trials for readability
            if idx % 3 == 0 and idx < len(sorted_results):
                story.append(PageBreak())

        # ===== APPENDIX =====
        story.append(PageBreak())
        story.append(Paragraph("Appendix: Methodology & Definitions", self.styles['SectionHeader']))
        story.append(Spacer(1, 0.15 * inch))

        story.append(Paragraph("<b>Match Score Calculation:</b>", self.styles['SubsectionHeader']))
        story.append(Paragraph(
            "Match scores are calculated based on alignment between patient characteristics and trial "
            "eligibility criteria. Scores range from 0-100% and reflect the degree of compatibility.",
            self.styles['MediConnectBody']
        ))

        story.append(Spacer(1, 0.1 * inch))
        story.append(Paragraph("<b>Match Categories:</b>", self.styles['SubsectionHeader']))

        category_definitions = [
            ['<b>Strong Match (80-100%)</b>',
             'High compatibility with trial criteria. Recommended for immediate clinical review.'],
            ['<b>Potential Match (60-79%)</b>',
             'Moderate compatibility. Further evaluation needed to confirm eligibility.'],
            ['<b>Weak Match (40-59%)</b>',
             'Limited compatibility. May require protocol amendments or patient condition changes.'],
            ['<b>Disqualified (<40%)</b>',
             'Insufficient match or exclusion criteria met. Not recommended for enrollment.']
        ]

        for cat, definition in category_definitions:
            story.append(Paragraph(f"{cat}: {definition}", self.styles['SmallText']))
            story.append(Spacer(1, 0.05 * inch))

        story.append(Spacer(1, 0.15 * inch))
        story.append(Paragraph("<b>Disclaimer:</b>", self.styles['SubsectionHeader']))
        story.append(Paragraph(
            "This report is generated by MediConnect's automated matching system and is intended to assist "
            "healthcare professionals in identifying potential clinical trial opportunities. Final eligibility "
            "determination must be made by qualified clinical personnel through comprehensive patient evaluation. "
            "This report does not constitute medical advice or a recommendation for treatment.",
            self.styles['SmallText']
        ))

        # Build PDF with custom header/footer
        doc.build(story, onFirstPage=template.header_footer, onLaterPages=template.header_footer)

        # Get PDF bytes
        pdf_bytes = buffer.getvalue()
        buffer.close()

        return pdf_bytes

    def _calculate_age(self, dob: str) -> str:
        """Calculate age from date of birth string"""
        try:
            if not dob or dob == 'N/A':
                return 'N/A'

            dob_date = datetime.strptime(dob, '%Y-%m-%d')
            today = datetime.now()
            age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))
            return f"{age} years"
        except:
            return 'N/A'

    def _get_category_color(self, category: str) -> str:
        """Get color hex code for match category"""
        color_map = {
            'Strong Match': '#2e7d32',
            'Potential Match': '#f57c00',
            'Weak Match': '#c62828',
            'Disqualified': '#757575'
        }
        return color_map.get(category, '#000000')

    def _format_criterion_data(self, criterion: Dict[str, Any]) -> str:
        """Format criterion data for display"""
        patient_value = criterion.get('patient_value', '')
        if patient_value:
            return str(patient_value)

        data = criterion.get('data', {})
        if isinstance(data, dict):
            formatted = ', '.join(f"{k}: {v}" for k, v in data.items())
            return formatted if formatted else 'N/A'

        return str(data) if data else 'N/A'


