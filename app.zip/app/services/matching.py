from typing import List, Dict, Any, Tuple
from datetime import date, datetime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.models import (
    Patient, ClinicalTrial, MatchSession, MatchResult,
    Diagnosis, Medication, LabResult, TreatmentHistory,
    Biomarker, PerformanceStatus, InclusionCriterion,
    ExclusionCriterion, MatchCategory
)


class MatchingService:
    """Service for matching patients to clinical trials"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def match_patient_to_trials(self, patient_id: int) -> MatchSession:
        """
        Match a patient to all active clinical trials
        Returns a MatchSession with all match results
        """
        # Get patient with all related data
        patient = await self._get_patient_with_data(patient_id)
        if not patient:
            raise ValueError(f"Patient {patient_id} not found")

        # Get all active trials
        result = await self.db.execute(
            select(ClinicalTrial).where(
                ClinicalTrial.is_active == True,
                ClinicalTrial.status.in_([
                    "Active-Enrolling",
                    "Planning"
                ])
            )
        )
        trials = result.scalars().all()

        # Create match session
        session = MatchSession(
            patient_id=patient_id,
            trials_evaluated=len(trials)
        )
        self.db.add(session)
        await self.db.flush()

        # Match against each trial
        for trial in trials:
            match_result = await self._evaluate_trial_match(patient, trial, session.id)
            self.db.add(match_result)

        await self.db.commit()
        await self.db.refresh(session)

        return session

    async def _get_patient_with_data(self, patient_id: int) -> Patient:
        """Get patient with all related medical data"""
        result = await self.db.execute(
            select(Patient).where(Patient.id == patient_id)
        )
        patient = result.scalar_one_or_none()

        if patient:
            # Load relationships
            await self.db.refresh(patient, [
                'diagnoses', 'medications', 'lab_results',
                'treatments', 'biomarkers', 'performance_statuses'
            ])

        return patient

    async def _evaluate_trial_match(
            self,
            patient: Patient,
            trial: ClinicalTrial,
            session_id: int
    ) -> MatchResult:
        """Evaluate how well a patient matches a specific trial"""

        # Load trial criteria
        await self.db.refresh(trial, ['inclusion_criteria', 'exclusion_criteria'])

        # Check exclusion criteria first
        exclusion_met = []
        for exclusion in trial.exclusion_criteria:
            if self._check_exclusion_criterion(patient, exclusion):
                exclusion_met.append({
                    'type': exclusion.criterion_type,
                    'data': exclusion.criterion_data,
                    'reason': 'Patient meets exclusion criterion'
                })

        # If any exclusion criteria are met, patient is disqualified
        if exclusion_met:
            return MatchResult(
                session_id=session_id,
                trial_id=trial.id,
                match_score=0.0,
                match_category=MatchCategory.DISQUALIFIED,
                confidence_score=100.0,
                criteria_met=[],
                criteria_not_met=[],
                criteria_missing_data=[],
                exclusion_criteria_met=exclusion_met,
                recommendations=[]
            )

        # Evaluate inclusion criteria
        criteria_met = []
        criteria_not_met = []
        criteria_missing_data = []
        total_weight = 0
        matched_weight = 0
        data_completeness_count = 0
        data_available_count = 0

        for inclusion in trial.inclusion_criteria:
            total_weight += inclusion.importance_weight
            data_available_count += 1

            result = self._check_inclusion_criterion(patient, inclusion)

            if result['status'] == 'met':
                criteria_met.append({
                    'type': inclusion.criterion_type,
                    'data': inclusion.criterion_data,
                    'weight': inclusion.importance_weight,
                    'patient_value': result['patient_value']
                })
                matched_weight += inclusion.importance_weight
                data_completeness_count += 1
            elif result['status'] == 'not_met':
                criteria_not_met.append({
                    'type': inclusion.criterion_type,
                    'data': inclusion.criterion_data,
                    'weight': inclusion.importance_weight,
                    'reason': result['reason']
                })
                data_completeness_count += 1
            else:  # missing_data
                criteria_missing_data.append({
                    'type': inclusion.criterion_type,
                    'data': inclusion.criterion_data,
                    'weight': inclusion.importance_weight,
                    'recommendation': result['recommendation']
                })

        # Calculate match score
        match_score = (matched_weight / total_weight * 100) if total_weight > 0 else 0

        # Calculate confidence score based on data completeness
        confidence_score = (data_completeness_count / data_available_count * 100) if data_available_count > 0 else 0

        # Determine match category
        if match_score >= 80:
            category = MatchCategory.STRONG_MATCH
        elif match_score >= 60:
            category = MatchCategory.POTENTIAL_MATCH
        elif match_score >= 40:
            category = MatchCategory.WEAK_MATCH
        else:
            category = MatchCategory.DISQUALIFIED

        # Generate recommendations
        recommendations = [item['recommendation'] for item in criteria_missing_data]

        return MatchResult(
            session_id=session_id,
            trial_id=trial.id,
            match_score=match_score,
            match_category=category,
            confidence_score=confidence_score,
            criteria_met=criteria_met,
            criteria_not_met=criteria_not_met,
            criteria_missing_data=criteria_missing_data,
            exclusion_criteria_met=[],
            recommendations=recommendations
        )

    def _check_inclusion_criterion(
            self,
            patient: Patient,
            criterion: InclusionCriterion
    ) -> Dict[str, Any]:
        """Check if patient meets an inclusion criterion"""

        criterion_type = criterion.criterion_type
        criterion_data = criterion.criterion_data

        if criterion_type == 'age':
            return self._check_age_criterion(patient, criterion_data)
        elif criterion_type == 'diagnosis':
            return self._check_diagnosis_criterion(patient, criterion_data)
        elif criterion_type == 'biomarker':
            return self._check_biomarker_criterion(patient, criterion_data)
        elif criterion_type == 'lab':
            return self._check_lab_criterion(patient, criterion_data)
        elif criterion_type == 'medication':
            return self._check_medication_criterion(patient, criterion_data)
        elif criterion_type == 'treatment':
            return self._check_treatment_criterion(patient, criterion_data)
        elif criterion_type == 'performance':
            return self._check_performance_criterion(patient, criterion_data)
        else:
            return {'status': 'missing_data', 'recommendation': f'Unknown criterion type: {criterion_type}'}

    def _check_age_criterion(self, patient: Patient, data: Dict) -> Dict[str, Any]:
        """Check age range criterion"""
        today = date.today()
        age = today.year - patient.date_of_birth.year - (
                (today.month, today.day) < (patient.date_of_birth.month, patient.date_of_birth.day)
        )

        min_age = data.get('min_age', 0)
        max_age = data.get('max_age', 150)

        if min_age <= age <= max_age:
            return {
                'status': 'met',
                'patient_value': f'{age} years old'
            }
        else:
            return {
                'status': 'not_met',
                'reason': f'Patient age {age} is outside range {min_age}-{max_age}'
            }

    def _check_diagnosis_criterion(self, patient: Patient, data: Dict) -> Dict[str, Any]:
        """Check required diagnosis criterion"""
        required_icd10 = data.get('icd10_code')

        if not required_icd10:
            return {'status': 'missing_data', 'recommendation': 'Required ICD-10 code not specified'}

        for diagnosis in patient.diagnoses:
            if diagnosis.icd10_code == required_icd10:
                return {
                    'status': 'met',
                    'patient_value': f'{diagnosis.icd10_code}: {diagnosis.description}'
                }

        return {
            'status': 'not_met',
            'reason': f'Patient does not have required diagnosis: {required_icd10}'
        }

    def _check_biomarker_criterion(self, patient: Patient, data: Dict) -> Dict[str, Any]:
        """Check biomarker criterion"""
        marker_name = data.get('marker_name')
        required_result = data.get('required_result')

        if not marker_name:
            return {'status': 'missing_data', 'recommendation': 'Biomarker name not specified'}

        for biomarker in patient.biomarkers:
            if biomarker.marker_name.lower() == marker_name.lower():
                if biomarker.result.lower() == required_result.lower():
                    return {
                        'status': 'met',
                        'patient_value': f'{biomarker.marker_name}: {biomarker.result}'
                    }
                else:
                    return {
                        'status': 'not_met',
                        'reason': f'{marker_name} is {biomarker.result}, required {required_result}'
                    }

        return {
            'status': 'missing_data',
            'recommendation': f'Test for biomarker: {marker_name}'
        }

    def _check_lab_criterion(self, patient: Patient, data: Dict) -> Dict[str, Any]:
        """Check laboratory value criterion"""
        test_name = data.get('test_name')
        min_value = data.get('min_value')
        max_value = data.get('max_value')

        if not test_name:
            return {'status': 'missing_data', 'recommendation': 'Lab test name not specified'}

        # Get most recent lab result for this test
        matching_labs = [lab for lab in patient.lab_results if lab.test_name.lower() == test_name.lower()]

        if not matching_labs:
            return {
                'status': 'missing_data',
                'recommendation': f'Perform lab test: {test_name}'
            }

        latest_lab = max(matching_labs, key=lambda x: x.test_date)
        value = latest_lab.result_value

        if (min_value is None or value >= min_value) and (max_value is None or value <= max_value):
            return {
                'status': 'met',
                'patient_value': f'{test_name}: {value} {latest_lab.unit}'
            }
        else:
            return {
                'status': 'not_met',
                'reason': f'{test_name} value {value} outside required range'
            }

    def _check_medication_criterion(self, patient: Patient, data: Dict) -> Dict[str, Any]:
        """Check current medication criterion"""
        drug_name = data.get('drug_name')

        if not drug_name:
            return {'status': 'missing_data', 'recommendation': 'Medication name not specified'}

        for med in patient.medications:
            if med.drug_name.lower() == drug_name.lower() and (med.end_date is None or med.end_date >= date.today()):
                return {
                    'status': 'met',
                    'patient_value': f'{med.drug_name} {med.dosage} {med.frequency}'
                }

        return {
            'status': 'not_met',
            'reason': f'Patient not currently taking {drug_name}'
        }

    def _check_treatment_criterion(self, patient: Patient, data: Dict) -> Dict[str, Any]:
        """Check prior treatment criterion"""
        treatment_type = data.get('treatment_type')

        if not treatment_type:
            return {'status': 'missing_data', 'recommendation': 'Treatment type not specified'}

        for treatment in patient.treatments:
            if treatment.treatment_type.lower() == treatment_type.lower():
                return {
                    'status': 'met',
                    'patient_value': f'{treatment.treatment_type}: {treatment.description}'
                }

        return {
            'status': 'not_met',
            'reason': f'Patient has not received {treatment_type}'
        }

    def _check_performance_criterion(self, patient: Patient, data: Dict) -> Dict[str, Any]:
        """Check performance status criterion"""
        if not patient.performance_statuses:
            return {
                'status': 'missing_data',
                'recommendation': 'Assess patient performance status (ECOG/Karnofsky)'
            }

        latest_status = max(patient.performance_statuses, key=lambda x: x.assessment_date)

        if 'ecog_max' in data and latest_status.ecog_score is not None:
            if latest_status.ecog_score <= data['ecog_max']:
                return {
                    'status': 'met',
                    'patient_value': f'ECOG score: {latest_status.ecog_score}'
                }
            else:
                return {
                    'status': 'not_met',
                    'reason': f'ECOG score {latest_status.ecog_score} exceeds maximum {data["ecog_max"]}'
                }

        if 'karnofsky_min' in data and latest_status.karnofsky_score is not None:
            if latest_status.karnofsky_score >= data['karnofsky_min']:
                return {
                    'status': 'met',
                    'patient_value': f'Karnofsky score: {latest_status.karnofsky_score}'
                }
            else:
                return {
                    'status': 'not_met',
                    'reason': f'Karnofsky score {latest_status.karnofsky_score} below minimum {data["karnofsky_min"]}'
                }

        return {
            'status': 'missing_data',
            'recommendation': 'Complete performance status assessment'
        }

    def _check_exclusion_criterion(
            self,
            patient: Patient,
            criterion: ExclusionCriterion
    ) -> bool:
        """Check if patient meets an exclusion criterion (returns True if EXCLUDED)"""

        criterion_type = criterion.criterion_type
        criterion_data = criterion.criterion_data

        if criterion_type == 'diagnosis':
            prohibited_icd10 = criterion_data.get('icd10_code')
            for diagnosis in patient.diagnoses:
                if diagnosis.icd10_code == prohibited_icd10:
                    return True

        elif criterion_type == 'biomarker':
            marker_name = criterion_data.get('marker_name')
            prohibited_result = criterion_data.get('prohibited_result')
            for biomarker in patient.biomarkers:
                if (biomarker.marker_name.lower() == marker_name.lower() and
                        biomarker.result.lower() == prohibited_result.lower()):
                    return True

        elif criterion_type == 'medication':
            drug_name = criterion_data.get('drug_name')
            for med in patient.medications:
                if med.drug_name.lower() == drug_name.lower() and (
                        med.end_date is None or med.end_date >= date.today()):
                    return True

        elif criterion_type == 'treatment':
            treatment_type = criterion_data.get('treatment_type')
            for treatment in patient.treatments:
                if treatment.treatment_type.lower() == treatment_type.lower():
                    return True

        return False