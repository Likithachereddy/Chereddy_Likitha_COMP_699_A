from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List
import io

from app.db.session import get_db
from app.models.models import User, Patient, MatchSession, MatchResult, ClinicalTrial
from app.schemas.schemas import MatchSessionResponse, MatchResultDetail, MatchReportRequest
from app.api.auth import get_current_active_user
from app.services.matching import MatchingService
from app.services.reports import ReportGenerator
from app.core.security import decrypt_data

router = APIRouter(prefix="/matching", tags=["Matching"])


def check_coordinator_role(current_user: User):
    """Verify user has Research Coordinator role"""
    if current_user.role.value not in ["Research Coordinator", "System Administrator"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only Research Coordinators can access this resource"
        )


@router.post("/{patient_id}", response_model=MatchSessionResponse)
async def match_patient(
        patient_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """
    Match a patient to all active clinical trials.
    URL param 'patient_id' corresponds to the Patient's MRN (User ID).
    """
    check_coordinator_role(current_user)

    # 1. Verify patient exists using MRN (patient_id column), not PK (id)
    result = await db.execute(
        select(Patient).where(Patient.patient_id == patient_id, Patient.is_active == True)
    )
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Patient with ID {patient_id} not found or inactive"
        )

    # Perform matching
    # Note: We pass the Database PK (patient.id) to the service, not the MRN
    matching_service = MatchingService(db)
    try:
        session = await matching_service.match_patient_to_trials(patient.id)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error during matching: {str(e)}"
        )

    # Load session with results
    await db.refresh(session, ['match_results'])

    # Load trial details for each result
    match_details = []
    for result in session.match_results:
        await db.refresh(result, ['trial'])

        match_detail = MatchResultDetail(
            trial_id=result.trial.id,
            protocol_number=result.trial.protocol_number,
            trial_title=result.trial.title,
            match_score=result.match_score,
            match_category=result.match_category,
            confidence_score=result.confidence_score,
            criteria_met=result.criteria_met or [],
            criteria_not_met=result.criteria_not_met or [],
            criteria_missing_data=result.criteria_missing_data or [],
            exclusion_criteria_met=result.exclusion_criteria_met or [],
            recommendations=result.recommendations or [],
            contact_info=result.trial.contact_info if result.match_category.value in ['Strong Match',
                                                                                      'Potential Match'] else None
        )
        match_details.append(match_detail)

    # Sort by match score (highest first)
    match_details.sort(key=lambda x: x.match_score, reverse=True)

    # Decrypt patient name for response
    patient.first_name = decrypt_data(patient.first_name)
    patient.last_name = decrypt_data(patient.last_name)

    return MatchSessionResponse(
        session_id=session.id,
        patient_id=patient.patient_id, # Return MRN
        patient_name=f"{patient.first_name} {patient.last_name}",
        session_date=session.session_date,
        trials_evaluated=session.trials_evaluated,
        match_results=match_details
    )


@router.get("/sessions/{session_id}", response_model=MatchSessionResponse)
async def get_match_session(
        session_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Get details of a previous matching session"""
    check_coordinator_role(current_user)

    result = await db.execute(
        select(MatchSession).where(MatchSession.id == session_id)
    )
    session = result.scalar_one_or_none()

    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Match session not found"
        )

    # Load relationships
    await db.refresh(session, ['patient', 'match_results'])

    # Load trial details for each result
    match_details = []
    for result in session.match_results:
        await db.refresh(result, ['trial'])

        match_detail = MatchResultDetail(
            trial_id=result.trial.id,
            protocol_number=result.trial.protocol_number,
            trial_title=result.trial.title,
            match_score=result.match_score,
            match_category=result.match_category,
            confidence_score=result.confidence_score,
            criteria_met=result.criteria_met or [],
            criteria_not_met=result.criteria_not_met or [],
            criteria_missing_data=result.criteria_missing_data or [],
            exclusion_criteria_met=result.exclusion_criteria_met or [],
            recommendations=result.recommendations or [],
            contact_info=result.trial.contact_info if result.match_category.value in ['Strong Match',
                                                                                      'Potential Match'] else None
        )
        match_details.append(match_detail)

    # Sort by match score
    match_details.sort(key=lambda x: x.match_score, reverse=True)

    # Decrypt patient name
    session.patient.first_name = decrypt_data(session.patient.first_name)
    session.patient.last_name = decrypt_data(session.patient.last_name)

    return MatchSessionResponse(
        session_id=session.id,
        patient_id=session.patient.patient_id, # MRN
        patient_name=f"{session.patient.first_name} {session.patient.last_name}",
        session_date=session.session_date,
        trials_evaluated=session.trials_evaluated,
        match_results=match_details
    )


@router.get("/patient/{patient_id}/history")
async def get_patient_match_history(
        patient_id: int,
        skip: int = 0,
        limit: int = 10,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Get matching history for a patient (by MRN)"""
    check_coordinator_role(current_user)

    # 1. Lookup PK using MRN
    p_result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = p_result.scalar_one_or_none()

    if not patient:
        # If patient not found, return empty history rather than error
        return []

    # 2. Query sessions using PK
    result = await db.execute(
        select(MatchSession)
        .where(MatchSession.patient_id == patient.id)
        .order_by(MatchSession.session_date.desc())
        .offset(skip)
        .limit(limit)
    )
    sessions = result.scalars().all()

    history = []
    for session in sessions:
        history.append({
            'session_id': session.id,
            'session_date': session.session_date,
            'trials_evaluated': session.trials_evaluated
        })

    return history


@router.post("/report/generate")
async def generate_match_report(
        report_request: MatchReportRequest,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Generate PDF report for a matching session"""
    check_coordinator_role(current_user)

    # Get session
    result = await db.execute(
        select(MatchSession).where(MatchSession.id == report_request.session_id)
    )
    session = result.scalar_one_or_none()

    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Match session not found"
        )

    # Load relationships
    await db.refresh(session, ['patient', 'match_results'])

    # Prepare patient data
    session.patient.first_name = decrypt_data(session.patient.first_name)
    session.patient.last_name = decrypt_data(session.patient.last_name)

    patient_data = {
        'patient_id': session.patient.patient_id,
        'first_name': session.patient.first_name,
        'last_name': session.patient.last_name,
        'date_of_birth': session.patient.date_of_birth.strftime('%Y-%m-%d'),
        'gender': session.patient.gender or 'N/A',
        'ethnicity': session.patient.ethnicity or 'N/A'
    }

    # Prepare match results
    match_results = []
    for result in session.match_results:
        await db.refresh(result, ['trial'])

        match_results.append({
            'protocol_number': result.trial.protocol_number,
            'trial_title': result.trial.title,
            'match_score': result.match_score,
            'match_category': result.match_category.value,
            'confidence_score': result.confidence_score,
            'criteria_met': result.criteria_met or [],
            'criteria_not_met': result.criteria_not_met or [],
            'criteria_missing_data': result.criteria_missing_data or [],
            'exclusion_criteria_met': result.exclusion_criteria_met or [],
            'recommendations': result.recommendations or [],
            'contact_info': result.trial.contact_info
        })

    report_generator = ReportGenerator()
    pdf_bytes = report_generator.generate_match_report(
        patient_data=patient_data,
        match_results=match_results,
        session_date=session.session_date
    )

    filename = f"match_report_{session.patient.patient_id}_{session.session_date.strftime('%Y%m%d')}.pdf"

    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )


@router.get("/compare/{session_id}")
async def compare_trials(
        session_id: int,
        trial_ids: str,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Compare match explanations for multiple trials side-by-side"""
    check_coordinator_role(current_user)

    # Parse trial IDs
    trial_id_list = [int(tid.strip()) for tid in trial_ids.split(',')]

    # Get match results for specified trials
    result = await db.execute(
        select(MatchResult)
        .where(
            MatchResult.session_id == session_id,
            MatchResult.trial_id.in_(trial_id_list)
        )
    )
    results = result.scalars().all()

    comparison = []
    for match_result in results:
        await db.refresh(match_result, ['trial'])

        comparison.append({
            'trial_id': match_result.trial.id,
            'protocol_number': match_result.trial.protocol_number,
            'trial_title': match_result.trial.title,
            'match_score': match_result.match_score,
            'match_category': match_result.match_category.value,
            'confidence_score': match_result.confidence_score,
            'criteria_met': match_result.criteria_met or [],
            'criteria_not_met': match_result.criteria_not_met or [],
            'criteria_missing_data': match_result.criteria_missing_data or [],
            'exclusion_criteria_met': match_result.exclusion_criteria_met or []
        })

    return {'comparison': comparison}