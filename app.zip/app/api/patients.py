from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, HTTPException, status, Form, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, cast, String
from typing import List, Optional

from app.core.utils import save_upload_file
from app.db.session import get_db
from app.models.models import User, Patient, Diagnosis, Medication, LabResult, TreatmentHistory, Biomarker, \
    PerformanceStatus
from app.schemas.schemas import (
    PatientCreate, PatientUpdate, PatientResponse,
    DiagnosisCreate, DiagnosisResponse,
    MedicationCreate, MedicationResponse,
    LabResultCreate, LabResultResponse,
    TreatmentHistoryCreate, TreatmentHistoryResponse,
    BiomarkerCreate, BiomarkerResponse,
    PerformanceStatusCreate, PerformanceStatusResponse
)
from app.api.auth import get_current_active_user
from app.core.security import encrypt_data, decrypt_data

router = APIRouter(prefix="/patients", tags=["Patients"])


def check_coordinator_role(current_user: User):
    """Verify user has Research Coordinator role"""
    if current_user.role.value not in ["Research Coordinator", "System Administrator"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only Research Coordinators can access this resource"
        )


@router.post("", response_model=PatientResponse, status_code=status.HTTP_201_CREATED)
async def create_patient(
        patient_id: int = Form(...),
        first_name: str = Form(...),
        last_name: str = Form(...),
        date_of_birth: date = Form(...),
        gender: Optional[str] = Form(None),
        ethnicity: Optional[str] = Form(None),
        photo: UploadFile = File(None),
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user),
):
    check_coordinator_role(current_user)

    # Check existence
    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    if result.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Patient ID already exists")

    photo_url = await save_upload_file(photo) if photo else None

    db_patient = Patient(
        patient_id=patient_id,
        first_name=encrypt_data(first_name),
        last_name=encrypt_data(last_name),
        date_of_birth=date_of_birth,
        gender=gender,
        ethnicity=ethnicity,
        profile_photo_url=photo_url
    )

    db.add(db_patient)
    await db.commit()
    await db.refresh(db_patient)

    return PatientResponse(
        id=db_patient.id,
        patient_id=db_patient.patient_id,
        first_name=first_name,
        last_name=last_name,
        date_of_birth=db_patient.date_of_birth,
        gender=db_patient.gender,
        ethnicity=db_patient.ethnicity,
        profile_photo_url=db_patient.profile_photo_url,
        is_active=db_patient.is_active,
        created_at=db_patient.created_at
    )


@router.get("/{patient_id}", response_model=PatientResponse)
async def get_patient(
        patient_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user),
):
    check_coordinator_role(current_user)

    # Search by patient_id (MRN)
    result = await db.execute(
        select(Patient).where(Patient.patient_id == patient_id)
    )
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    return PatientResponse(
        id=patient.id,
        patient_id=patient.patient_id,
        first_name=decrypt_data(patient.first_name),
        last_name=decrypt_data(patient.last_name),
        date_of_birth=patient.date_of_birth,
        gender=patient.gender,
        ethnicity=patient.ethnicity,
        is_active=patient.is_active,
        created_at=patient.created_at,
    )


@router.get("", response_model=List[PatientResponse])
async def list_patients(
        skip: int = 0,
        limit: int = 100,
        search: str = None,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user),
):
    check_coordinator_role(current_user)

    query = select(Patient).where(Patient.is_active == True)

    if search:
        # FIX: Cast Integer ID to String for ILIKE search
        # This handles the "operator does not exist: integer ~~* character varying" error
        query = query.where(cast(Patient.patient_id, String).ilike(f"%{search}%"))

    result = await db.execute(query.offset(skip).limit(limit))
    patients = result.scalars().all()

    return [
        PatientResponse(
            id=p.id,
            patient_id=p.patient_id,
            first_name=decrypt_data(p.first_name),
            last_name=decrypt_data(p.last_name),
            date_of_birth=p.date_of_birth,
            gender=p.gender,
            ethnicity=p.ethnicity,
            is_active=p.is_active,
            created_at=p.created_at,
        )
        for p in patients
    ]


@router.patch("/{patient_id}", response_model=PatientResponse)
async def update_patient(
        patient_id: int,
        first_name: Optional[str] = Form(None),
        last_name: Optional[str] = Form(None),
        date_of_birth: Optional[date] = Form(None),
        gender: Optional[str] = Form(None),
        ethnicity: Optional[str] = Form(None),
        photo: UploadFile = File(None),
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    if first_name:
        patient.first_name = encrypt_data(first_name)
    if last_name:
        patient.last_name = encrypt_data(last_name)
    if date_of_birth:
        patient.date_of_birth = date_of_birth
    if gender:
        patient.gender = gender
    if ethnicity:
        patient.ethnicity = ethnicity

    if photo:
        patient.profile_photo_url = await save_upload_file(photo)

    await db.commit()
    await db.refresh(patient)

    return PatientResponse(
        id=patient.id,
        patient_id=patient.patient_id,
        first_name=decrypt_data(patient.first_name),
        last_name=decrypt_data(patient.last_name),
        date_of_birth=patient.date_of_birth,
        gender=patient.gender,
        ethnicity=patient.ethnicity,
        profile_photo_url=patient.profile_photo_url,
        is_active=patient.is_active,
        created_at=patient.created_at,
    )


@router.delete("/{patient_id}", status_code=status.HTTP_204_NO_CONTENT)
async def deactivate_patient(
        patient_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(
        select(Patient).where(Patient.patient_id == patient_id)
    )
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    patient.is_active = False
    await db.commit()


# ==========================================
# SUB-RESOURCE ENDPOINTS
# ==========================================

# Diagnosis
@router.post("/{patient_id}/diagnoses", response_model=DiagnosisResponse, status_code=status.HTTP_201_CREATED)
async def add_diagnosis(
        patient_id: int,
        diagnosis: DiagnosisCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    db_diagnosis = Diagnosis(**diagnosis.model_dump(exclude={'patient_id'}), patient_id=patient.id)

    db.add(db_diagnosis)
    await db.commit()
    await db.refresh(db_diagnosis)

    return db_diagnosis


@router.get("/{patient_id}/diagnoses", response_model=List[DiagnosisResponse])
async def get_patient_diagnoses(
        patient_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    result = await db.execute(
        select(Diagnosis).where(Diagnosis.patient_id == patient.id)
    )
    return result.scalars().all()


# Medications
@router.post("/{patient_id}/medications", response_model=MedicationResponse, status_code=status.HTTP_201_CREATED)
async def add_medication(
        patient_id: int,
        medication: MedicationCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    db_medication = Medication(**medication.model_dump(exclude={'patient_id'}), patient_id=patient.id)

    db.add(db_medication)
    await db.commit()
    await db.refresh(db_medication)

    return db_medication


@router.get("/{patient_id}/medications", response_model=List[MedicationResponse])
async def get_patient_medications(
        patient_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    result = await db.execute(
        select(Medication).where(Medication.patient_id == patient.id)
    )
    return result.scalars().all()


# Lab Results
@router.post("/{patient_id}/lab-results", response_model=LabResultResponse, status_code=status.HTTP_201_CREATED)
async def add_lab_result(
        patient_id: int,
        lab_result: LabResultCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    db_lab_result = LabResult(**lab_result.model_dump(exclude={'patient_id'}), patient_id=patient.id)

    db.add(db_lab_result)
    await db.commit()
    await db.refresh(db_lab_result)

    return db_lab_result


@router.get("/{patient_id}/lab-results", response_model=List[LabResultResponse])
async def get_patient_lab_results(
        patient_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    result = await db.execute(
        select(LabResult).where(LabResult.patient_id == patient.id)
    )
    return result.scalars().all()


# Treatment History
@router.post("/{patient_id}/treatments", response_model=TreatmentHistoryResponse, status_code=status.HTTP_201_CREATED)
async def add_treatment_history(
        patient_id: int,
        treatment: TreatmentHistoryCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    db_treatment = TreatmentHistory(**treatment.model_dump(exclude={'patient_id'}), patient_id=patient.id)

    db.add(db_treatment)
    await db.commit()
    await db.refresh(db_treatment)

    return db_treatment


@router.get("/{patient_id}/treatments", response_model=List[TreatmentHistoryResponse])
async def get_patient_treatments(
        patient_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    result = await db.execute(
        select(TreatmentHistory).where(TreatmentHistory.patient_id == patient.id)
    )
    return result.scalars().all()


# Biomarkers
@router.post("/{patient_id}/biomarkers", response_model=BiomarkerResponse, status_code=status.HTTP_201_CREATED)
async def add_biomarker(
        patient_id: int,
        biomarker: BiomarkerCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    db_biomarker = Biomarker(**biomarker.model_dump(exclude={'patient_id'}), patient_id=patient.id)

    db.add(db_biomarker)
    await db.commit()
    await db.refresh(db_biomarker)

    return db_biomarker


@router.get("/{patient_id}/biomarkers", response_model=List[BiomarkerResponse])
async def get_patient_biomarkers(
        patient_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    result = await db.execute(
        select(Biomarker).where(Biomarker.patient_id == patient.id)
    )
    return result.scalars().all()


# Performance Status
@router.post("/{patient_id}/performance-status", response_model=PerformanceStatusResponse,
             status_code=status.HTTP_201_CREATED)
async def add_performance_status(
        patient_id: int,
        performance: PerformanceStatusCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    db_performance = PerformanceStatus(**performance.model_dump(exclude={'patient_id'}), patient_id=patient.id)

    db.add(db_performance)
    await db.commit()
    await db.refresh(db_performance)

    return db_performance


@router.get("/{patient_id}/performance-status", response_model=List[PerformanceStatusResponse])
async def get_patient_performance_status(
        patient_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    check_coordinator_role(current_user)

    result = await db.execute(select(Patient).where(Patient.patient_id == patient_id))
    patient = result.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    result = await db.execute(
        select(PerformanceStatus).where(PerformanceStatus.patient_id == patient.id)
    )
    return result.scalars().all()

# Delete Helpers
@router.delete("/diagnoses/{diagnosis_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_diagnosis(diagnosis_id: int, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    check_coordinator_role(current_user)
    result = await db.execute(select(Diagnosis).where(Diagnosis.id == diagnosis_id))
    item = result.scalar_one_or_none()
    if not item: raise HTTPException(404, "Diagnosis not found")
    await db.delete(item)
    await db.commit()

@router.delete("/medications/{med_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_medication(med_id: int, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    check_coordinator_role(current_user)
    result = await db.execute(select(Medication).where(Medication.id == med_id))
    item = result.scalar_one_or_none()
    if not item: raise HTTPException(404, "Medication not found")
    await db.delete(item)
    await db.commit()

@router.delete("/lab-results/{lab_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_lab_result(lab_id: int, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    check_coordinator_role(current_user)
    result = await db.execute(select(LabResult).where(LabResult.id == lab_id))
    item = result.scalar_one_or_none()
    if not item: raise HTTPException(404, "Lab Result not found")
    await db.delete(item)
    await db.commit()