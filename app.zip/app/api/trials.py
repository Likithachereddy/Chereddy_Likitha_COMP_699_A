from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_
from typing import List

from app.db.session import get_db
from app.models.models import (
    User, ClinicalTrial, TrialDiseaseFocus,
    InclusionCriterion, ExclusionCriterion
)
from app.schemas.schemas import (
    ClinicalTrialCreate, ClinicalTrialUpdate, ClinicalTrialResponse,
    InclusionCriterionCreate, ExclusionCriterionCreate
)
from app.api.auth import get_current_active_user

router = APIRouter(prefix="/trials", tags=["Clinical Trials"])


def check_trial_admin_role(current_user: User):
    """Verify user has Trial Administrator role"""
    if current_user.role.value not in ["Trial Administrator", "System Administrator"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only Trial Administrators can access this resource"
        )


@router.post("", response_model=ClinicalTrialResponse, status_code=status.HTTP_201_CREATED)
async def create_trial(
        trial: ClinicalTrialCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Create a new clinical trial"""
    check_trial_admin_role(current_user)

    # Check if protocol number already exists
    result = await db.execute(
        select(ClinicalTrial).where(ClinicalTrial.protocol_number == trial.protocol_number)
    )
    if result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Protocol number already exists"
        )

    # Create trial
    trial_data = trial.model_dump(exclude={'disease_focus'})
    db_trial = ClinicalTrial(**trial_data)
    db.add(db_trial)
    await db.flush()

    # Add disease focus
    for disease in trial.disease_focus:
        db_disease = TrialDiseaseFocus(
            trial_id=db_trial.id,
            **disease.model_dump()
        )
        db.add(db_disease)

    await db.commit()
    await db.refresh(db_trial)

    return db_trial


@router.get("/{trial_id}", response_model=ClinicalTrialResponse)
async def get_trial(
        trial_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Get trial by ID"""
    result = await db.execute(
        select(ClinicalTrial).where(ClinicalTrial.id == trial_id)
    )
    trial = result.scalar_one_or_none()

    if not trial:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Trial not found"
        )

    return trial


@router.get("", response_model=List[ClinicalTrialResponse])
async def list_trials(
        skip: int = 0,
        limit: int = 100,
        search: str = None,
        active_only: bool = True,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """List all trials with optional search"""
    query = select(ClinicalTrial)

    if active_only:
        query = query.where(ClinicalTrial.is_active == True)

    if search:
        query = query.where(
            or_(
                ClinicalTrial.protocol_number.ilike(f"%{search}%"),
                ClinicalTrial.title.ilike(f"%{search}%"),
                ClinicalTrial.sponsor_name.ilike(f"%{search}%")
            )
        )

    query = query.offset(skip).limit(limit)
    result = await db.execute(query)

    return result.scalars().all()


@router.patch("/{trial_id}", response_model=ClinicalTrialResponse)
async def update_trial(
        trial_id: int,
        trial_update: ClinicalTrialUpdate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Update trial information"""
    check_trial_admin_role(current_user)

    result = await db.execute(
        select(ClinicalTrial).where(ClinicalTrial.id == trial_id)
    )
    trial = result.scalar_one_or_none()

    if not trial:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Trial not found"
        )

    update_data = trial_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(trial, field, value)

    await db.commit()
    await db.refresh(trial)

    return trial


@router.delete("/{trial_id}", status_code=status.HTTP_204_NO_CONTENT)
async def deactivate_trial(
        trial_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Deactivate trial (soft delete)"""
    check_trial_admin_role(current_user)

    result = await db.execute(
        select(ClinicalTrial).where(ClinicalTrial.id == trial_id)
    )
    trial = result.scalar_one_or_none()

    if not trial:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Trial not found"
        )

    trial.is_active = False
    await db.commit()


# Inclusion Criteria
@router.post("/{trial_id}/inclusion-criteria", status_code=status.HTTP_201_CREATED)
async def add_inclusion_criterion(
        trial_id: int,
        criterion: InclusionCriterionCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Add inclusion criterion to trial"""
    check_trial_admin_role(current_user)

    # Verify trial exists
    result = await db.execute(
        select(ClinicalTrial).where(ClinicalTrial.id == trial_id)
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Trial not found")

    db_criterion = InclusionCriterion(**criterion.model_dump(), trial_id=trial_id)
    db.add(db_criterion)
    await db.commit()
    await db.refresh(db_criterion)

    return db_criterion


@router.get("/{trial_id}/inclusion-criteria")
async def get_inclusion_criteria(
        trial_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Get all inclusion criteria for a trial"""
    result = await db.execute(
        select(InclusionCriterion).where(InclusionCriterion.trial_id == trial_id)
    )
    return result.scalars().all()


@router.delete("/inclusion-criteria/{criterion_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_inclusion_criterion(
        criterion_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Delete inclusion criterion"""
    check_trial_admin_role(current_user)

    result = await db.execute(
        select(InclusionCriterion).where(InclusionCriterion.id == criterion_id)
    )
    criterion = result.scalar_one_or_none()

    if not criterion:
        raise HTTPException(status_code=404, detail="Criterion not found")

    await db.delete(criterion)
    await db.commit()


# Exclusion Criteria
@router.post("/{trial_id}/exclusion-criteria", status_code=status.HTTP_201_CREATED)
async def add_exclusion_criterion(
        trial_id: int,
        criterion: ExclusionCriterionCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Add exclusion criterion to trial"""
    check_trial_admin_role(current_user)

    # Verify trial exists
    result = await db.execute(
        select(ClinicalTrial).where(ClinicalTrial.id == trial_id)
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Trial not found")

    db_criterion = ExclusionCriterion(**criterion.model_dump(), trial_id=trial_id)
    db.add(db_criterion)
    await db.commit()
    await db.refresh(db_criterion)

    return db_criterion


@router.get("/{trial_id}/exclusion-criteria")
async def get_exclusion_criteria(
        trial_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Get all exclusion criteria for a trial"""
    result = await db.execute(
        select(ExclusionCriterion).where(ExclusionCriterion.trial_id == trial_id)
    )
    return result.scalars().all()


@router.delete("/exclusion-criteria/{criterion_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_exclusion_criterion(
        criterion_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Delete exclusion criterion"""
    check_trial_admin_role(current_user)

    result = await db.execute(
        select(ExclusionCriterion).where(ExclusionCriterion.id == criterion_id)
    )
    criterion = result.scalar_one_or_none()

    if not criterion:
        raise HTTPException(status_code=404, detail="Criterion not found")

    await db.delete(criterion)
    await db.commit()