import asyncio

from fastapi import FastAPI, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.auth import get_current_active_user
from app.core.config import get_settings
from app.db.session import init_db, get_db, engine, Base
from app.api import auth, patients, trials, matching, users
from app.models import User, Patient, ClinicalTrial, MatchSession

settings = get_settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifecycle manager for the application"""
    print("Initializing database...")
    print("Database initialized successfully!")
    yield
    print("Shutting down...")

app = FastAPI(
    title=settings.APP_NAME,
    description="API for Clinical Trial Patient Matching System",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[""],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    """
    Serves the Single Page Application (SPA) entry point.
    Jinja2 injects the 'request' context which is required for url_for to work.
    """
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy"}

@app.get("/api/dashboard/stats")
async def get_dashboard_stats(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Fetch real-time counts for the dashboard"""
    p_result = await db.execute(select(func.count(Patient.id)).where(Patient.is_active == True))
    patient_count = p_result.scalar() or 0

    t_result = await db.execute(select(func.count(ClinicalTrial.id)).where(ClinicalTrial.is_active == True))
    trial_count = t_result.scalar() or 0

    s_result = await db.execute(select(func.count(MatchSession.id)))
    session_count = s_result.scalar() or 0

    return {
        "active_patients": patient_count,
        "active_trials": trial_count,
        "total_sessions": session_count
    }

app.include_router(auth.router, prefix="/api")
app.include_router(patients.router, prefix="/api")
app.include_router(trials.router, prefix="/api")
app.include_router(matching.router, prefix="/api")
app.include_router(users.router, prefix="/api")

if __name__ == "__main__":
    import uvicorn
    asyncio.run(init_db())
    uvicorn.run(
        "main:app",
        host="localhost",
        port=8000,
        reload=settings.DEBUG
    )