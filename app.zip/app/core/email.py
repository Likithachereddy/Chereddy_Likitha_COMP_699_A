from fastapi_mail import FastMail, MessageSchema, ConnectionConfig, MessageType
from pydantic import EmailStr
from app.core.config import get_settings

settings = get_settings()

conf = ConnectionConfig(
    MAIL_USERNAME=settings.MAIL_USERNAME,
    MAIL_PASSWORD=settings.MAIL_PASSWORD,
    MAIL_FROM=settings.MAIL_FROM,
    MAIL_PORT=settings.MAIL_PORT,
    MAIL_SERVER=settings.MAIL_SERVER,
    MAIL_STARTTLS=True,
    MAIL_SSL_TLS=False,
    USE_CREDENTIALS=True,
    VALIDATE_CERTS=True
)


async def send_onboarding_email(email: EmailStr, username: str, temp_password: str):
    html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to MedConnect</title>
    </head>
    <body style="margin: 0; padding: 0; background-color: #f4f7fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f4f7fa;">
            <tr>
                <td style="padding: 40px 20px;">
                    <!-- Main Container -->
                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">

                        <!-- Header -->
                        <tr>
                            <td style="background: linear-gradient(135deg, #0A4D68 0%, #088395 100%); padding: 40px 30px; text-align: center; border-radius: 12px 12px 0 0;">
                                <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 600; letter-spacing: -0.5px;">
                                    🏥 Welcome to MedConnect
                                </h1>
                                <p style="margin: 10px 0 0 0; color: #e3f2fd; font-size: 16px;">
                                    Clinical Trial Patient Matching System
                                </p>
                            </td>
                        </tr>

                        <!-- Body Content -->
                        <tr>
                            <td style="padding: 40px 30px;">
                                <!-- Greeting -->
                                <h2 style="margin: 0 0 20px 0; color: #1a1a1a; font-size: 22px; font-weight: 600;">
                                    Hello, {username}! 👋
                                </h2>

                                <p style="margin: 0 0 20px 0; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                    Your account has been successfully created! We're excited to have you join our platform for connecting patients with clinical trials.
                                </p>

                                <!-- Important Notice -->
                                <div style="background: linear-gradient(135deg, #fff3cd 0%, #fff8e1 100%); border-left: 4px solid #ffc107; padding: 16px 20px; margin: 25px 0; border-radius: 6px;">
                                    <p style="margin: 0; color: #856404; font-size: 14px; font-weight: 600;">
                                        ⚠️ Important: Password Change Required
                                    </p>
                                    <p style="margin: 8px 0 0 0; color: #856404; font-size: 14px; line-height: 1.5;">
                                        For security reasons, you'll be required to change your password upon first login.
                                    </p>
                                </div>

                                <!-- Credentials Box -->
                                <div style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); border: 2px solid #0A4D68; border-radius: 10px; padding: 25px; margin: 25px 0;">
                                    <h3 style="margin: 0 0 20px 0; color: #0A4D68; font-size: 18px; font-weight: 600; text-align: center;">
                                        🔐 Your Login Credentials
                                    </h3>

                                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                        <tr>
                                            <td style="padding: 12px 0; border-bottom: 1px solid #dee2e6;">
                                                <span style="color: #6c757d; font-size: 14px; font-weight: 500;">Username:</span>
                                            </td>
                                            <td style="padding: 12px 0; border-bottom: 1px solid #dee2e6; text-align: right;">
                                                <span style="color: #1a1a1a; font-size: 15px; font-weight: 600; font-family: 'Courier New', monospace;">{username}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 12px 0;">
                                                <span style="color: #6c757d; font-size: 14px; font-weight: 500;">Temporary Password:</span>
                                            </td>
                                            <td style="padding: 12px 0; text-align: right;">
                                                <span style="color: #1a1a1a; font-size: 15px; font-weight: 600; font-family: 'Courier New', monospace; background-color: #fff; padding: 6px 12px; border-radius: 4px; border: 1px solid #dee2e6;">{temp_password}</span>
                                            </td>
                                        </tr>
                                    </table>
                                </div>

                                <!-- CTA Button -->
                                <div style="text-align: center; margin: 35px 0 25px 0;">
                                    <a href="http://localhost:8000" style="display: inline-block; background: linear-gradient(135deg, #0A4D68 0%, #088395 100%); color: #ffffff; text-decoration: none; padding: 16px 40px; border-radius: 8px; font-size: 16px; font-weight: 600; box-shadow: 0 4px 6px rgba(10, 77, 104, 0.3); transition: all 0.3s ease;">
                                        Login to MedConnect →
                                    </a>
                                </div>

                                <!-- Help Section -->
                                <div style="background-color: #f8f9fa; border-radius: 8px; padding: 20px; margin: 25px 0;">
                                    <p style="margin: 0 0 10px 0; color: #495057; font-size: 14px; font-weight: 600;">
                                        💡 Need Help?
                                    </p>
                                    <p style="margin: 0; color: #6c757d; font-size: 14px; line-height: 1.5;">
                                        If you have any questions or need assistance, please don't hesitate to contact our support team.
                                    </p>
                                </div>

                                <!-- Signature -->
                                <p style="margin: 30px 0 0 0; color: #4a5568; font-size: 15px; line-height: 1.6;">
                                    Best regards,<br>
                                    <strong style="color: #0A4D68;">The MedConnect Team</strong><br>
                                    <span style="color: #6c757d; font-size: 13px;">System Administrator</span>
                                </p>
                            </td>
                        </tr>

                        <!-- Footer -->
                        <tr>
                            <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-radius: 0 0 12px 12px; border-top: 1px solid #e9ecef;">
                                <p style="margin: 0 0 10px 0; color: #6c757d; font-size: 13px;">
                                    This is an automated message from the Clinical Trial Patient Matching System
                                </p>
                                <p style="margin: 0; color: #adb5bd; font-size: 12px;">
                                    © 2024 MedConnect. All rights reserved.
                                </p>
                                <div style="margin-top: 15px;">
                                    <a href="#" style="color: #088395; text-decoration: none; font-size: 12px; margin: 0 10px;">Privacy Policy</a>
                                    <span style="color: #dee2e6;">|</span>
                                    <a href="#" style="color: #088395; text-decoration: none; font-size: 12px; margin: 0 10px;">Terms of Service</a>
                                    <span style="color: #dee2e6;">|</span>
                                    <a href="#" style="color: #088395; text-decoration: none; font-size: 12px; margin: 0 10px;">Contact Support</a>
                                </div>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>
    </html>
    """

    message = MessageSchema(
        subject="🏥 Welcome to MedConnect - Account Created",
        recipients=[email],
        body=html,
        subtype=MessageType.html
    )

    fm = FastMail(conf)
    await fm.send_message(message)