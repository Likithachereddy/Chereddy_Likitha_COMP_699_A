from sqlalchemy import Column, Integer, String, Date, DateTime, Float, Boolean, Text, ForeignKey, Enum, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import datetime
import enum
from app.db.session import Base


class UserRole(str, enum.Enum):
    """User role enumeration"""
    RESEARCH_COORDINATOR = "Research Coordinator"
    TRIAL_ADMINISTRATOR = "Trial Administrator"
    SYSTEM_ADMINISTRATOR = "System Administrator"


class TrialStatus(str, enum.Enum):
    """Clinical trial status enumeration"""
    PLANNING = "Planning"
    ACTIVE_ENROLLING = "Active-Enrolling"
    ACTIVE_NOT_ENROLLING = "Active-Not Enrolling"
    SUSPENDED = "Suspended"
    COMPLETED = "Completed"
    TERMINATED = "Terminated"


class MatchCategory(str, enum.Enum):
    """Match category enumeration"""
    STRONG_MATCH = "Strong Match"
    POTENTIAL_MATCH = "Potential Match"
    WEAK_MATCH = "Weak Match"
    DISQUALIFIED = "Disqualified"


class User(Base):
    """User model for authentication and authorization"""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    force_password_change = Column(Boolean, default=True)
    role = Column(Enum(UserRole), nullable=False)
    profile_photo_url = Column(String(500), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class Patient(Base):
    """Patient profile model"""
    __tablename__ = "patients"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, unique=True, index=True, nullable=False)
    first_name = Column(Text, nullable=False)  # Encrypted
    last_name = Column(Text, nullable=False)  # Encrypted
    date_of_birth = Column(Date, nullable=False)
    gender = Column(String(20))
    profile_photo_url = Column(String(500), nullable=True)
    ethnicity = Column(String(100))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    diagnoses = relationship("Diagnosis", back_populates="patient", cascade="all, delete-orphan")
    medications = relationship("Medication", back_populates="patient", cascade="all, delete-orphan")
    lab_results = relationship("LabResult", back_populates="patient", cascade="all, delete-orphan")
    treatments = relationship("TreatmentHistory", back_populates="patient", cascade="all, delete-orphan")
    biomarkers = relationship("Biomarker", back_populates="patient", cascade="all, delete-orphan")
    performance_statuses = relationship("PerformanceStatus", back_populates="patient", cascade="all, delete-orphan")
    match_sessions = relationship("MatchSession", back_populates="patient", cascade="all, delete-orphan")


class Diagnosis(Base):
    """Patient diagnosis model"""
    __tablename__ = "diagnoses"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    icd10_code = Column(String(10), index=True, nullable=False)
    description = Column(String(500), nullable=False)
    diagnosis_date = Column(Date, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    patient = relationship("Patient", back_populates="diagnoses")


class Medication(Base):
    """Patient medication model"""
    __tablename__ = "medications"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    drug_name = Column(String(200), nullable=False)
    dosage = Column(String(100), nullable=False)
    frequency = Column(String(100), nullable=False)
    route = Column(String(50), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    patient = relationship("Patient", back_populates="medications")


class LabResult(Base):
    """Patient laboratory test result model"""
    __tablename__ = "lab_results"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    test_name = Column(String(200), nullable=False)
    result_value = Column(Float, nullable=False)
    unit = Column(String(50), nullable=False)
    reference_range = Column(String(100))
    test_date = Column(Date, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    patient = relationship("Patient", back_populates="lab_results")


class TreatmentHistory(Base):
    """Patient treatment history model"""
    __tablename__ = "treatment_history"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    treatment_type = Column(String(100), nullable=False)  # therapy, surgery, radiation
    description = Column(Text, nullable=False)
    treatment_date = Column(Date, nullable=False)
    outcome = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    patient = relationship("Patient", back_populates="treatments")


class Biomarker(Base):
    """Patient biomarker and genetic marker model"""
    __tablename__ = "biomarkers"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    marker_name = Column(String(200), nullable=False)
    result = Column(String(100), nullable=False)  # positive/negative or numeric
    test_date = Column(Date, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    patient = relationship("Patient", back_populates="biomarkers")


class PerformanceStatus(Base):
    """Patient performance status model"""
    __tablename__ = "performance_status"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    ecog_score = Column(Integer)  # 0-5
    karnofsky_score = Column(Integer)  # 0-100
    assessment_date = Column(Date, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    patient = relationship("Patient", back_populates="performance_statuses")


class ClinicalTrial(Base):
    """Clinical trial model"""
    __tablename__ = "clinical_trials"

    id = Column(Integer, primary_key=True, index=True)
    protocol_number = Column(String(50), unique=True, index=True, nullable=False)
    nct_number = Column(String(50), unique=True, index=True)
    title = Column(String(500), nullable=False)
    sponsor_name = Column(String(200), nullable=False)
    principal_investigator = Column(String(200), nullable=False)
    phase = Column(String(20))
    status = Column(Enum(TrialStatus), default=TrialStatus.PLANNING)
    target_enrollment = Column(Integer)
    estimated_duration = Column(String(100))
    study_sites = Column(JSON)  # Array of site locations
    contact_info = Column(JSON)  # Contact details
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    disease_focus = relationship("TrialDiseaseFocus", back_populates="trial", cascade="all, delete-orphan")
    inclusion_criteria = relationship("InclusionCriterion", back_populates="trial", cascade="all, delete-orphan")
    exclusion_criteria = relationship("ExclusionCriterion", back_populates="trial", cascade="all, delete-orphan")
    match_results = relationship("MatchResult", back_populates="trial", cascade="all, delete-orphan")


class TrialDiseaseFocus(Base):
    """Trial disease focus using ICD-10 codes"""
    __tablename__ = "trial_disease_focus"

    id = Column(Integer, primary_key=True, index=True)
    trial_id = Column(Integer, ForeignKey("clinical_trials.id"), nullable=False)
    icd10_code = Column(String(10), index=True, nullable=False)
    description = Column(String(500))

    trial = relationship("ClinicalTrial", back_populates="disease_focus")


class InclusionCriterion(Base):
    """Trial inclusion criteria model"""
    __tablename__ = "inclusion_criteria"

    id = Column(Integer, primary_key=True, index=True)
    trial_id = Column(Integer, ForeignKey("clinical_trials.id"), nullable=False)
    criterion_type = Column(String(50),
                            nullable=False)  # age, diagnosis, biomarker, lab, medication, treatment, performance
    criterion_data = Column(JSON, nullable=False)  # Structured data for the criterion
    importance_weight = Column(Integer, nullable=False)  # 1-5
    logical_operator = Column(String(10), default="AND")  # AND/OR
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    trial = relationship("ClinicalTrial", back_populates="inclusion_criteria")


class ExclusionCriterion(Base):
    """Trial exclusion criteria model"""
    __tablename__ = "exclusion_criteria"

    id = Column(Integer, primary_key=True, index=True)
    trial_id = Column(Integer, ForeignKey("clinical_trials.id"), nullable=False)
    criterion_type = Column(String(50), nullable=False)  # diagnosis, biomarker, lab, medication, treatment
    criterion_data = Column(JSON, nullable=False)  # Structured data for the criterion
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    trial = relationship("ClinicalTrial", back_populates="exclusion_criteria")


class MatchSession(Base):
    """Patient-trial matching session model"""
    __tablename__ = "match_sessions"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    session_date = Column(DateTime(timezone=True), server_default=func.now())
    trials_evaluated = Column(Integer, default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    patient = relationship("Patient", back_populates="match_sessions")
    match_results = relationship("MatchResult", back_populates="session", cascade="all, delete-orphan")


class MatchResult(Base):
    """Individual trial match result model"""
    __tablename__ = "match_results"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("match_sessions.id"), nullable=False)
    trial_id = Column(Integer, ForeignKey("clinical_trials.id"), nullable=False)
    match_score = Column(Float, nullable=False)  # 0-100
    match_category = Column(Enum(MatchCategory), nullable=False)
    confidence_score = Column(Float, nullable=False)  # 0-100
    criteria_met = Column(JSON)  # List of met inclusion criteria
    criteria_not_met = Column(JSON)  # List of unmet inclusion criteria
    criteria_missing_data = Column(JSON)  # List of criteria with missing data
    exclusion_criteria_met = Column(JSON)  # List of met exclusion criteria (disqualifying)
    recommendations = Column(JSON)  # Recommended additional tests/data
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    session = relationship("MatchSession", back_populates="match_results")
    trial = relationship("ClinicalTrial", back_populates="match_results")